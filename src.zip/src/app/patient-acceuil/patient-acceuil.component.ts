import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-acceuil',
  templateUrl: './patient-acceuil.component.html',
  styleUrls: ['./patient-acceuil.component.css']
})
export class PatientAcceuilComponent {

}
