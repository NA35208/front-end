import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientAcceuilComponent } from './patient-acceuil.component';

describe('PatientAcceuilComponent', () => {
  let component: PatientAcceuilComponent;
  let fixture: ComponentFixture<PatientAcceuilComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientAcceuilComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PatientAcceuilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
