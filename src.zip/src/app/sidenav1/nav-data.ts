export const navbarData = [
    {
        routeLink: 'Profil',
        icon: 'fas fa-address-card',
        label: 'Profil'
    },
    
  
    {
        routeLink: 'Medecins',
        icon: 'fas fa-user-md',
        label: 'Medecins',
     
    },
    
    {
        routeLink: 'patients',
        icon: 'fas fa-procedures',
        label: 'Patients'
    },
    {
        routeLink: 'Chambre',
        icon: 'fas fa-hospital',
        label: 'Chambre'
    },
    {
        routeLink: 'Statistique',
        icon: 'fas fa-analytics',
        label: 'Statistique'
    },
];