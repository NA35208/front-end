import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navhome',
  templateUrl: './navhome.component.html',
  styleUrls: ['./navhome.component.scss']
})
export class NavhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
