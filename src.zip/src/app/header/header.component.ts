import { Component, HostListener, Input, OnInit } from '@angular/core';
import { notifications, userItems } from './header-dummy-data';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit{

@Input() collapsed = false ;
@Input() screenWidth=0 ;

canShowSearchAsOverlay =false ;
selectedNotification : any ;

notifications = notifications; 
userItems = userItems;

constractor(){}

@HostListener('window:resize', ['$event'])
onResize(event: any) {
  this.checkCanShowSearchAsOverlay(window.innerWidth);
   }


ngOnInit(): void {
    this.checkCanShowSearchAsOverlay(window.innerWidth);
    this.selectedNotification=this.notifications[0];
}
getHeadClass() : string {
  let StyleClass = '';
  if(this.collapsed && this.screenWidth > 768){
    StyleClass = 'head-trimmed';
  }else {
    StyleClass = 'head-md-screen';
  }
 return StyleClass ;
}
checkCanShowSearchAsOverlay(innerWidth : number):void{
if(innerWidth < 845){
  this.canShowSearchAsOverlay=true;
}else{
  this.canShowSearchAsOverlay=false;
}
}

}
