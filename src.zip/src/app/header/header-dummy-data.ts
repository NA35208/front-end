export const notifications = [
    {
        icon: 'far fa-cloud-download',
        subject:'téléchargement complet',
        description:'téléchargement de fichier x est complet',
    },
    {
        icon: 'far fa-cloud-download',
        subject:'téléchargement complet',
        description:'téléchargement de fichier x est complet',
    },
    {
        icon: 'far fa-cloud-download',
        subject:'téléchargement complet',
        description:'téléchargement de fichier x est complet',
    }
]

export const userItems = [
    {
        icon:'far fa-user',
        label:'Profile'
    },
    {
        icon:'far fa-cog',
        label:'Configuration'
    },
    {
        icon:'far fa-power-off',
        label:'Déconnexion'
    }
]