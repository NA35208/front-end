import { Component } from '@angular/core';

@Component({
  selector: 'app-gestionnaire-profil',
  templateUrl: './gestionnaire-profil.component.html',
  styleUrls: ['./gestionnaire-profil.component.scss']
})
export class GestionnaireProfilComponent {

}
