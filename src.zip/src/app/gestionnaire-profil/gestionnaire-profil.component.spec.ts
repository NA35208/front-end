import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionnaireProfilComponent } from './gestionnaire-profil.component';

describe('GestionnaireProfilComponent', () => {
  let component: GestionnaireProfilComponent;
  let fixture: ComponentFixture<GestionnaireProfilComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GestionnaireProfilComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GestionnaireProfilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
