import { Component, OnInit } from '@angular/core';
import { Medecin } from '../Model/Medecin';
import { MedecinsService } from '../services/medecins.service';
import { HttpErrorResponse } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { catchError, of, tap } from 'rxjs';
import { Specialite } from '../Model/Specialite';
import { CliniqueService } from '../services/clinique.service';



interface SideNavToggle {
	screenWidth: number;
	collapsed: boolean;
  }
  

@Component({
  selector: 'app-gestion-medecins',
  templateUrl: './gestion-medecins.component.html',
  styleUrls: ['./gestion-medecins.component.scss']
})





export class GestionMedecinsComponent  implements OnInit{
	
  medecins: Medecin[]=[];
  cliniqueId!: number;
	editMedecin!: Medecin;
	removeMedecin!: Medecin;
	specialities = Object.values(Specialite);

  
	constructor(private employeeService:	MedecinsService){
	

	}
  
	ngOnInit() {
	  this.getEmployees();
	}
  
	public getEmployees(): void {
		this.employeeService.getEmployees()
		  .pipe(
			tap((response: Medecin[]) => {
			  this.medecins = response;
			  console.log(this.medecins);
			})
		  )
		  .subscribe(
			() => {},
			(error: HttpErrorResponse) => {
			  alert(error.message);
			}
		  );
	  }
  
	  public addMedecin(addForm: NgForm): void {
		const addEmployeeForm = document.getElementById('add-employee-form');
		if (addEmployeeForm) {
		  addEmployeeForm.click();
		}
		this.employeeService.addEmployee(addForm.value).subscribe(
		  (response: Medecin) => {
			console.log(response);
			this.getEmployees();
			addForm.reset();
		  },
		  (error: HttpErrorResponse) => {
			alert(error.message);
			addForm.reset();
		  }
		);
	  }
	  
  
	  public updateMedecin(employee: Medecin): void {
		 this.employeeService.updateEmployee(employee).subscribe(
      (response: Medecin) => {
        console.log(response);
        this.getEmployees();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      }
    );
	  }
	  
	  public deleteMedecin(medecinId: number): void {
		this.employeeService.deleteEmployee(medecinId).subscribe(
      (response: void) => {
        console.log(response);
        this.getEmployees();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      }
    );
	  }
	  
	isSideNavCollapsed = false;
	screenWidth = 0;
  
	onToggleSideNav(data: SideNavToggle): void {
	  this.screenWidth = data.screenWidth;
	  this.isSideNavCollapsed = data.collapsed;
	}
  
		
	public searchEmployees(key: string): void {
	  console.log(key);
	  const results: Medecin[] = [];
	  for (const employee of this.medecins) {
		if (employee.nom.toLowerCase().indexOf(key.toLowerCase()) !== -1
		|| employee.prenom.toLowerCase().indexOf(key.toLowerCase()) !== -1
		|| employee.email.toLowerCase().indexOf(key.toLowerCase()) !== -1
		|| employee.code.toLowerCase().indexOf(key.toLowerCase()) !== -1) {
		  results.push(employee);
		}
	  }
	  this.medecins = results;
	  if (results.length === 0 || !key) {
		this.getEmployees();
	  }
	}
  
	public onOpenModal(employee   :  Medecin |null, mode: string): void {
	  const container = document.getElementById('main-container');
	  const button = document.createElement('button');
	  button.type = 'button';
	  button.style.display = 'none';
	  button.setAttribute('data-toggle', 'modal');
	  if (mode === 'add') {
		button.setAttribute('data-target', '#addMedecinModal');
	  }
	  if (mode === 'edit' && employee !== null) {
		this.editMedecin = employee;
		button.setAttribute('data-target', '#updateMedecinModal');
	  }
	  if (mode === 'delete' && employee !== null) {
		this.removeMedecin = employee;
		button.setAttribute('data-target', '#deleteMedecinModal');
	  }
	 container?.appendChild(button);
	  button.click();
	}
	
	



	

}
