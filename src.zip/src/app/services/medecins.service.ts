import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Medecin } from '../Model/Medecin';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MedecinsService {
 

  private apiServerUrl = environment.apiUrl;

  constructor(private http: HttpClient){}

  public getEmployees(): Observable<Medecin[]> {
    return this.http.get<Medecin[]>(`${this.apiServerUrl}/medecin/all`);
  }

  public addEmployee(medecin: Medecin): Observable<Medecin> {
    return this.http.post<Medecin>(`${this.apiServerUrl}/medecin/add`, medecin);
  }

  public updateEmployee(medecin: Medecin): Observable<Medecin> {
    return this.http.put<Medecin>(`${this.apiServerUrl}/medecin/update`, medecin);
  }

  public deleteEmployee(medecinId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiServerUrl}/medecin/delete/${medecinId}`);
  }
  

 


  
}
