import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Medecin } from '../Model/Medecin';

@Injectable({
  providedIn: 'root'
})
export class CliniqueService {
  private baseUrl = 'http://localhost:8080/clinique';

  constructor(private http: HttpClient){}
  getAllMedecins(cliniqueId: number): Observable<Medecin[]> {
    return this.http.get<Medecin[]>(`${this.baseUrl}${cliniqueId}/medecins`);
  }

  getMedecinById(cliniqueId: number, medecinId: number): Observable<Medecin> {
    return this.http.get<Medecin>(`${this.baseUrl}${cliniqueId}/medecins/${medecinId}`);
  }

  addMedecin(cliniqueId: number, medecin: Medecin): Observable<Medecin> {
    return this.http.post<Medecin>(`${this.baseUrl}${cliniqueId}/medecins`, medecin);
  }

  updateMedecin(cliniqueId: number, medecinId: number, medecin: Medecin): Observable<Medecin> {
    return this.http.put<Medecin>(`${this.baseUrl}${cliniqueId}/medecins/${medecinId}`, medecin);
  }

  deleteMedecin(cliniqueId: number, medecinId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}${cliniqueId}/medecins/${medecinId}`);
  }

}
