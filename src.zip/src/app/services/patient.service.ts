import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Patient } from '../Model/Patient';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PatientService {
  private apiServerUrl = environment.apiUrl;

  
  constructor(private http: HttpClient) { }

  findAll(): Observable<Patient[]> {
    return this.http.get<Patient[]>(`${this.apiServerUrl}/patients/all`);
  }

  findById(id: number): Observable<Patient> {
    return this.http.get<Patient>(`${this.apiServerUrl}/patients/${id}`);
  }

  save(patient: Patient): Observable<Patient> {
    return this.http.post<Patient>(`${this.apiServerUrl}/patients/add`, patient);
  }

  update(id: number, patient: Patient): Observable<Patient> {
    return this.http.put<Patient>(`${this.apiServerUrl}/patients/update/${id}`, patient);
  }

  deleteById(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiServerUrl}/patients/delete/${id}`);
  }
}
