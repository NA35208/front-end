import { Component } from '@angular/core';

@Component({
  selector: 'app-downpage',
  templateUrl: './downpage.component.html',
  styleUrls: ['./downpage.component.scss']
})
export class DownpageComponent {

}
