public  class fatim {
      public void static main(String args[]){
        system.out.println("fatim ");
      }
}
