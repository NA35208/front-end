import { Component } from '@angular/core';

@Component({
  selector: 'app-uppage',
  templateUrl: './uppage.component.html',
  styleUrls: ['./uppage.component.scss']
})
export class UppageComponent {

}
