import { Component } from '@angular/core';

@Component({
  selector: 'app-update-medecin',
  templateUrl: './update-medecin.component.html',
  styleUrls: ['./update-medecin.component.scss']
})
export class UpdateMedecinComponent {

}
