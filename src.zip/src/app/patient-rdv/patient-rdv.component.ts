import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-rdv',
  templateUrl: './patient-rdv.component.html',
  styleUrls: ['./patient-rdv.component.css']
})
export class PatientRdvComponent implements OnInit {
  
  bgImage!: string;

  ngOnInit() {
    this.changeBackground();
  }

  changeBackground() {
    const images = ['https://static6.depositphotos.com/1095795/668/i/600/depositphotos_6686794-stock-photo-blurred-doctors-surgery-corridor.jpg', 'https://media.istockphoto.com/id/1364075546/fr/photo/couloir-vide-dans-un-h%C3%B4pital-moderne-avec-comptoir-dinformation-et-lit-dh%C3%B4pital-dans-les.jpg?s=612x612&w=0&k=20&c=0ZYUOjngOlhsb-l_QCvRWR9ZOPqDZwd-9t56zIRvAhA='];
    const randomIndex = Math.floor(Math.random() * images.length);
    this.bgImage = `url('${images[randomIndex]}')`;

    setTimeout(() => {
      this.changeBackground();
    }, 5000);
  }}