export const navbarData = [
    {
        routeLink: 'dashboard',
        icon: 'far fa-tachometer-alt-slow',
        label: 'Contrôleur'
    },
    
  
    {
        routeLink: 'hospital',
        icon: 'fal fa-hospital',
        label: 'Établissement',
     
    },
    
    {
        routeLink: 'patients',
        icon: 'far fa-clipboard-user',
        label: 'Patients'
    },
    {
        routeLink: 'pages',
        icon: 'fal fa-file',
        label: 'Pages'
    },
    {
        routeLink: 'reviews',
        icon: 'far fa-comments',
        label: 'Commentaire'
    },
];