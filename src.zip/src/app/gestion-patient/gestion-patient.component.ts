import { Component } from '@angular/core';
import { Patient } from '../Model/Patient';
import { PatientService } from '../services/patient.service';
interface SideNavToggle {
	screenWidth: number;
	collapsed: boolean;}
@Component({
  selector: 'app-gestion-patient',
  templateUrl: './gestion-patient.component.html',
  styleUrls: ['./gestion-patient.component.scss']
})
export class GestionPatientComponent {

	
	isSideNavCollapsed = false;
	screenWidth = 0;
  
	onToggleSideNav(data: SideNavToggle): void {
	  this.screenWidth = data.screenWidth;
	  this.isSideNavCollapsed = data.collapsed;
	}
  
	patients: Patient[]=[];

	constructor(private patientService: PatientService) { }
  
	ngOnInit(): void {
	  this.findAllPatients();
	}
  
	findAllPatients(): void {
	  this.patientService.findAll().subscribe(patients => {
		this.patients = patients;
	  });
	}
  
	savePatient(patient: Patient): void {
	  this.patientService.save(patient).subscribe(() => {
		this.findAllPatients();
	  });
	}
  
	updatePatient(patient: Patient): void {
	  this.patientService.update(patient.id, patient).subscribe(() => {
		this.findAllPatients();
	  });
	}
  
	deletePatient(patient: Patient): void {
	  this.patientService.deleteById(patient.id).subscribe(() => {
		this.findAllPatients();
	  });
	}



}
