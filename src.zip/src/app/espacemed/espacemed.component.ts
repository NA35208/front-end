import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-espacemed',
  templateUrl: './espacemed.component.html',
  styleUrls: ['./espacemed.component.scss']
})
export class EspacemedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
