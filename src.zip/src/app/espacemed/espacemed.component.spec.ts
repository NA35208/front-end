import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EspacemedComponent } from './espacemed.component';

describe('EspacemedComponent', () => {
  let component: EspacemedComponent;
  let fixture: ComponentFixture<EspacemedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EspacemedComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EspacemedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
