import { Medecin } from "./Medecin";
import { Patient } from "./Patient";

export interface DossierMedical {
    id: number;
    allergies: string;
    antecedents: string;
    observations: string;
    patient: Patient;
    medecin: Medecin;
  
    
  }
  