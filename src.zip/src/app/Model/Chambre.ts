import { Clinique } from "./Clinique";

export interface Chambre {
    id: number;
    numero: string;
    capacite: number;
    prix: number;
    reservee: boolean;
    clinique: Clinique;
  
  
  }