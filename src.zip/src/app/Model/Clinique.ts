import { Chambre } from "./Chambre";
import { Medecin } from "./Medecin";
import { Patient } from "./Patient";

export interface Clinique {
    id: number;
    nomClinique: string;
    prixConsultation: number;
    image: string;
    medecins: Medecin[];
    patients: Patient[];
    chambres: Chambre[];
  }
  