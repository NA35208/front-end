import { DossierMedical } from "./DossierMedical";

export interface Patient {
    id: number;
    nom: string;
    cin: string;
    dateNaissance: Date;
    image: string;
    genre: string;
    tel: string;
    email: string;
    adresse: string;
    dossierMedical: DossierMedical;
    clinique: string;
    medecin: string;
  }
  