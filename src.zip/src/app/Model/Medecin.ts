import { Patient } from "./Patient";
import { Specialite } from "./Specialite";

export interface Medecin {
  id: number;
  code: string;
  cin: string;
  nom: string;
  prenom: string;
  dateNaissance: Date;
  genre: string;
  adresse: string;
  ville: string;
  tel: string;
  email: string;
  fax: string;
  nationnalite: string;
  image: string;
  clinique: string;
  diplome: string;
  patients: Patient[];
  specialites: Specialite[];
    
  }
  