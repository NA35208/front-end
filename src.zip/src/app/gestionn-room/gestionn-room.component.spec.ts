import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionnRoomComponent } from './gestionn-room.component';

describe('GestionnRoomComponent', () => {
  let component: GestionnRoomComponent;
  let fixture: ComponentFixture<GestionnRoomComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GestionnRoomComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GestionnRoomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
