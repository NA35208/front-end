import { Component } from '@angular/core';

@Component({
  selector: 'app-gestionn-room',
  templateUrl: './gestionn-room.component.html',
  styleUrls: ['./gestionn-room.component.css']
})
export class GestionnRoomComponent {

}
