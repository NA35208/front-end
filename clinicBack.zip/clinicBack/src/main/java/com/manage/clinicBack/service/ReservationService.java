package com.manage.clinicBack.service;

import com.manage.clinicBack.module.ReservationChambreDTO;

public interface ReservationService {
    void reserverChambre(ReservationChambreDTO reservationChambreDTO);
}

