package com.manage.clinicBack.Dao;

import com.manage.clinicBack.module.Chambre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;


public interface ChambreDao extends JpaRepository<Chambre,Long> {
    @Query("SELECT c FROM Chambre c WHERE c.numero = :numeroChambre AND c.clinique.id = :idHopital")
    Optional<Chambre> findByNumeroAndHopitalId(String numeroChambre, Long idHopital);
}
