package com.manage.clinicBack.module;

import lombok.Data;

@Data
public class ReservationChambreDTO {

    private String numeroChambre;

    private Long idHopital;


}
