package com.manage.clinicBack.module;

import jakarta.persistence.Entity;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
@Data
@Entity
@Table(name = "patient")
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;

    private String cin;

    private Date dateNaissance;

    private String image;

    private String genre;
    private String tel;
    private  String email;
    private  String adresse;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id")
    private     DossierMedical dossierMedical;

    private  String clinique;
    private  String medecin;

    private  int age;

    public Patient() {

    }

    @Transient
    public int getAge() {
        LocalDate birthdateLocal = this.dateNaissance.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate now = LocalDate.now();
        Period period = Period.between(birthdateLocal, now);
        return period.getYears();
    }
    public Patient(String nom, String cin, Date dateNaissance, String image, String genre, String tel, String email, String adresse, DossierMedical dossierMedical, String clinique, String medecin) {
        this.nom = nom;
        this.cin = cin;
        this.dateNaissance = dateNaissance;
        this.image = image;
        this.genre = genre;
        this.tel = tel;
        this.email = email;
        this.adresse = adresse;
        this.dossierMedical = dossierMedical;
        this.clinique = clinique;
        this.medecin = medecin;
        this.age = getAge();
    }


}
