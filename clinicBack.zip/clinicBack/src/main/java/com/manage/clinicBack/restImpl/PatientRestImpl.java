package com.manage.clinicBack.restImpl;

import com.manage.clinicBack.module.Patient;
import com.manage.clinicBack.rest.PatientRest;
import com.manage.clinicBack.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@RestController
public class PatientRestImpl implements PatientRest {
    @Autowired
    private PatientService patientService;
    @Override
    public List<Patient> findAll() {
        return patientService.findAll();
    }

    @Override
    public Patient findById(Long id) {

            return patientService.findById(id);
    }

    @Override
    public Patient save(Patient patient) {
        return patientService.save(patient);
    }

    @Override
    public Patient update(Long id,Patient patient) {
        Patient existingPatient = patientService.findById(id);
        existingPatient.setNom(patient.getNom());
        existingPatient.setCin(patient.getCin());
        existingPatient.setDateNaissance(patient.getDateNaissance());
        existingPatient.setImage(patient.getImage());
        existingPatient.setGenre(patient.getGenre());
        existingPatient.setTel(patient.getTel());
        existingPatient.setEmail(patient.getEmail());
        existingPatient.setAdresse(patient.getAdresse());
        existingPatient.setDossierMedical(patient.getDossierMedical());
        return patientService.save(existingPatient);
    }

    @Override
    public void deleteById(Long id) {
        patientService.deleteById(id);
    }
}
