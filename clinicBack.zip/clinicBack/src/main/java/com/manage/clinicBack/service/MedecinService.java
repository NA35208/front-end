package com.manage.clinicBack.service;

import com.manage.clinicBack.module.Medecin;
import jakarta.transaction.Transactional;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface MedecinService {


  ResponseEntity<List<Medecin>>getAllMedecin(String filterValue);
     Medecin getMedecinById(Long id);
    ResponseEntity<String>addNewMedecin(Map<String,String> requestMap);
  Medecin updateMedecin(Medecin medecin);


void deleteMedecin(Long id);
}
