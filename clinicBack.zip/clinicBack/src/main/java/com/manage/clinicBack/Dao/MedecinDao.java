package com.manage.clinicBack.Dao;

import com.manage.clinicBack.module.Medecin;

import com.manage.clinicBack.module.User;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface MedecinDao  extends JpaRepository<Medecin,  Long> {
    Medecin findByEmail(@Param("email") String email);
    void deleteMedecinById(Long id);

    Optional<Medecin> findMedecinById(Long id);

    @Query("SELECT m FROM Medecin m")
    List<Medecin> getAllMedecin();
    @Query("SELECT m FROM Medecin m")
    List<Medecin> findByAddress(String address);


    Medecin findByCin(String cin);
}
