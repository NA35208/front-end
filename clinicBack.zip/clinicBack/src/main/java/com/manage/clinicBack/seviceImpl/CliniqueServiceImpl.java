package com.manage.clinicBack.seviceImpl;

import com.manage.clinicBack.Dao.CliniqueDao;
import com.manage.clinicBack.exception.UserNotFoundException;
import com.manage.clinicBack.module.Clinique;
import com.manage.clinicBack.module.Medecin;
import com.manage.clinicBack.module.Patient;
import com.manage.clinicBack.service.CliniqueService;
import com.manage.clinicBack.service.MedecinService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Transactional
@Service
public class CliniqueServiceImpl implements CliniqueService {

    @Autowired
    private CliniqueDao cliniqueRepository;
    @Autowired
    private MedecinService medecinService;

    @Override
    public List<Clinique> getAllCliniques() {
        return cliniqueRepository.findAll();
    }

    @Override
    public Clinique getCliniqueById(Long id) {
        return cliniqueRepository.findById(id).orElse(null);
    }

    @Override
    public Clinique addClinique(Clinique clinique) {
        return cliniqueRepository.save(clinique);
    }

    @Override
    public Clinique updateClinique(Long id, Clinique clinique) {
        Clinique existingClinique = cliniqueRepository.findById(id).orElse(null);
        if (existingClinique != null) {
            existingClinique.setNomClinique(clinique.getNomClinique());
            existingClinique.setPrixConsultation(clinique.getPrixConsultation());
            existingClinique.setImage(clinique.getImage());
            return cliniqueRepository.save(existingClinique);
        } else {
            return null;
        }
    }

    @Override
    public void deleteClinique(Long id) {
        cliniqueRepository.deleteById(id);
    }

    @Override
    public List<Medecin> getAllMedecins(Long cliniqueId) {
        Optional<Clinique> cliniqueOptional = cliniqueRepository.findById(cliniqueId);
        if (cliniqueOptional.isPresent()) {
            return cliniqueOptional.get().getMedecins();
        }
        return new ArrayList<>();
    }

    @Override
    public Medecin getMedecinById(Long cliniqueId, Long medecinId) {
        Optional<Clinique> cliniqueOptional = cliniqueRepository.findById(cliniqueId);
        if (cliniqueOptional.isPresent()) {
            Clinique clinique = cliniqueOptional.get();
            Optional<Medecin> medecinOptional = clinique.getMedecins().stream()
                    .filter(medecin -> medecin.getId().equals(medecinId))
                    .findFirst();
            if (medecinOptional.isPresent()) {
                return medecinOptional.get();
            }
        }
        throw new UserNotFoundException("Medecin with id " + medecinId + " not found");
    }

    @Override

    public Medecin addMedecin(Long cliniqueId, Medecin medecin) {
        Optional<Clinique> cliniqueOptional = cliniqueRepository.findById(cliniqueId);
        if (cliniqueOptional.isPresent()) {
            Clinique clinique = cliniqueOptional.get();
            List<Medecin> medecins = clinique.getMedecins();
            medecin.setId(null);
            medecin.setClinique(clinique); // associer le médecin à la clinique
            medecins.add(medecin);
            clinique.setMedecins(medecins);
            cliniqueRepository.save(clinique); // sauvegarder la clinique (avec le nouveau médecin)
            return medecin;
        }
        throw new UserNotFoundException("Clinique with id " + cliniqueId + " not found");
    }



    @Override
    public Medecin updateMedecin(Long cliniqueId, Long medecinId, Medecin medecin) {
        Optional<Clinique> cliniqueOptional = cliniqueRepository.findById(cliniqueId);
        if (cliniqueOptional.isPresent()) {
            Clinique clinique = cliniqueOptional.get();
            Optional<Medecin> medecinOptional = clinique.getMedecins().stream()
                    .filter(m -> m.getId().equals(medecinId))
                    .findFirst();
            if (medecinOptional.isPresent()) {
                Medecin existingMedecin = medecinOptional.get();
                existingMedecin.setNom(medecin.getNom());
                existingMedecin.setPrenom(medecin.getPrenom());
                existingMedecin.setCin(medecin.getCin());
                existingMedecin.setCode(medecin.getCode());
                existingMedecin.setEmail(medecin.getEmail());
                existingMedecin.setFax(medecin.getFax());
                existingMedecin.setNationnalite(medecin.getNationnalite());
                existingMedecin.setDateNaissance(medecin.getDateNaissance());
                existingMedecin.setGenre(medecin.getGenre());
                existingMedecin.setAdresse(medecin.getAdresse());
                existingMedecin.setVille(medecin.getVille());
                existingMedecin.setImage(medecin.getImage());
                cliniqueRepository.save(clinique);
                return existingMedecin;
            }
            throw new UserNotFoundException("Medecin with id " + medecinId + " not found");
        }
        throw new UserNotFoundException("Clinique with id " + cliniqueId + " not found");
    }

    @Override
    public void deleteMedecin(Long cliniqueId, Long medecinId) {
        Optional<Clinique> cliniqueOptional = cliniqueRepository.findById(cliniqueId);
        if (cliniqueOptional.isPresent()) {
            Clinique clinique = cliniqueOptional.get();
            List<Medecin> medecins = clinique.getMedecins();
            medecins.removeIf(medecin -> medecin.getId().equals(medecinId));
            clinique.setMedecins(medecins);
            cliniqueRepository.save(clinique);
        } else {
            throw new UserNotFoundException("Clinique with id " + cliniqueId + " not found");
        }
    }

    public List<Patient> getAllPatientsByCliniqueId(Long cliniqueId) {
        Optional<Clinique> optionalClinique = cliniqueRepository.findById(cliniqueId);
        if (optionalClinique.isPresent()) {
            Clinique clinique = optionalClinique.get();
            return clinique.getPatients();
        } else {
            throw new UserNotFoundException("Clinique not found with id " + cliniqueId);
        }
    }

    @Override
    public Patient getPatientById(Long cliniqueId, Long patientId) {
        Optional<Clinique> optionalClinique = cliniqueRepository.findById(cliniqueId);
        if (optionalClinique.isPresent()) {
            Clinique clinique = optionalClinique.get();
            Optional<Patient> optionalPatient = clinique.getPatients().stream().filter(patient -> patient.getId().equals(patientId)).findFirst();
            if (optionalPatient.isPresent()) {
                return optionalPatient.get();
            } else {
                throw new UserNotFoundException("Patient not found with id " + patientId);
            }
        } else {
            throw new UserNotFoundException("Clinique not found with id " + cliniqueId);
        }
    }

    @Override
    public Patient addPatient(Long cliniqueId, Patient patient) {
        Optional<Clinique> optionalClinique = cliniqueRepository.findById(cliniqueId);
        if (optionalClinique.isPresent()) {
            Clinique clinique = optionalClinique.get();
            patient.setClinique(String.valueOf(clinique));
            List<Patient> patients = clinique.getPatients();
            patients.add(patient);
            clinique.setPatients(patients);
            return cliniqueRepository.save(clinique).getPatients().stream().filter(p -> p.equals(patient)).findFirst().get();
        } else {
            throw new UserNotFoundException("Clinique not found with id " + cliniqueId);
        }
    }

    @Override
    public Patient updatePatient(Long cliniqueId, Long patientId, Patient patient) {
        Optional<Clinique> optionalClinique = cliniqueRepository.findById(cliniqueId);
        if (optionalClinique.isPresent()) {
            Clinique clinique = optionalClinique.get();
            Optional<Patient> optionalPatient = clinique.getPatients().stream().filter(p -> p.getId().equals(patientId)).findFirst();
            if (optionalPatient.isPresent()) {
                Patient existingPatient = optionalPatient.get();


                existingPatient.setTel(patient.getTel());
                existingPatient.setEmail(patient.getEmail());
                existingPatient.setNom(patient.getNom());
                existingPatient.setCin(patient.getCin());
                existingPatient.setDateNaissance(patient.getDateNaissance());
                existingPatient.setImage(patient.getImage());
                existingPatient.setGenre(patient.getGenre());
                existingPatient.setTel(patient.getTel());
                existingPatient.setEmail(patient.getEmail());
                existingPatient.setAdresse(patient.getAdresse());
                existingPatient.setDossierMedical(patient.getDossierMedical());
                existingPatient.setClinique(patient.getClinique());
                existingPatient.setMedecin(patient.getMedecin());
                cliniqueRepository.save(clinique);
                return existingPatient;
            } else {
                throw new UserNotFoundException("Patient with id " + patientId + " not found in clinique with id " + cliniqueId);
            }
        } else {
            throw new UserNotFoundException("Clinique with id " + cliniqueId + " not found");
        }


        }

    @Override
    public void deletePatient(Long cliniqueId, Long patientId) {
        Optional<Clinique> cliniqueOptional = cliniqueRepository.findById(cliniqueId);
        if (cliniqueOptional.isPresent()) {
            Clinique clinique = cliniqueOptional.get();
            List<Patient> patients = clinique.getPatients();
            patients.removeIf(patient -> patient.getId().equals(patientId));
            clinique.setPatients(patients);
            cliniqueRepository.save(clinique);
        } else {
            throw new UserNotFoundException("Clinique with id " + cliniqueId + " not found");
        }
    }

}

