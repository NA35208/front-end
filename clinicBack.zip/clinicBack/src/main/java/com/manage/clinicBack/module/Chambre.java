package com.manage.clinicBack.module;

import jakarta.persistence.Entity;
import jakarta.persistence.*;
import lombok.Data;

@Data

@Entity
public class Chambre {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String numero;

    private int capacite;

    private double prix;

    private boolean reservee;

    @ManyToOne
    private Clinique clinique;

    // constructeurs, getters, setters
}
