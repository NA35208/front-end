package com.manage.clinicBack.module;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name="Dossier Medecal")

public class DossierMedical {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String allergies;
  private  String maladie;
    private String antecedents;

    private String observations;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id")
    private Patient patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "medecin_id")
    private Medecin medecin;

    // constructors, getters, and setters
}
