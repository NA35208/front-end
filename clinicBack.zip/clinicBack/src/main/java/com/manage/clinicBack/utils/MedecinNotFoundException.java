package com.manage.clinicBack.utils;

public class MedecinNotFoundException extends RuntimeException{
    public MedecinNotFoundException(String message){
        super(message);
    }
}
