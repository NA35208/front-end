package com.manage.clinicBack.seviceImpl;

import com.google.common.base.Strings;
import com.manage.clinicBack.Dao.MedecinDao;
import com.manage.clinicBack.JWT.JwtFilter;
import com.manage.clinicBack.constents.cliniqueConstants;
import com.manage.clinicBack.module.*;
import com.manage.clinicBack.service.MedecinService;
import com.manage.clinicBack.utils.ClinicUtils;
import com.manage.clinicBack.utils.MedecinNotFoundException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.util.*;
@Transactional
@Slf4j
@Service
public class MedecinServiceImpl implements MedecinService {

    @Autowired
    MedecinDao medecinDao;

     @Autowired
    JwtFilter jwtFilter;



    @Override
    public ResponseEntity<String> addNewMedecin(Map<String, String> requestMap) {
        try {
            if (validateMedecinMap(requestMap,false)) {

                Medecin medecin=medecinDao.findByCin(requestMap.get("Cin"));
                if (Objects.isNull(medecin)) {
                    medecinDao.save(getMedecinFromMap(requestMap,false));
                    return ClinicUtils.getResponseEntity("medecin bien enregistrer", HttpStatus.OK);
                } else {
                    return ClinicUtils.getResponseEntity("medecin existe déja", HttpStatus.BAD_REQUEST);
                }

            } else {
                return ClinicUtils.getResponseEntity(cliniqueConstants.INVALID_DATA, HttpStatus.BAD_REQUEST);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return ClinicUtils.getResponseEntity(cliniqueConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }



    private boolean validateMedecinMap(Map<String,String>requestMap,Boolean valideId) {
        if(requestMap.containsKey("nom")&&requestMap.containsKey("prenom")&&requestMap.containsKey("email")
        && requestMap.containsKey("code")&&
                requestMap.containsKey("nationnalite")&&requestMap.containsKey("adresse")&&requestMap.containsKey("cin")&&requestMap.containsKey("ville")&&requestMap.containsKey("diplome")&&
                requestMap.containsKey("tel")&& requestMap.containsKey("fax")&& requestMap.containsKey("genre")){

          if(requestMap.containsKey("id")&&valideId){
              return true;
          } else if (!valideId) {
              return true;
              
          }

        }
        return  false;
    }
    private Medecin getMedecinFromMap(Map<String,String> requestMap,boolean isAdd ){
      Medecin medecin=new Medecin();

      if(isAdd){
          medecin.setId(Long.valueOf(requestMap.get("id")));}
      medecin.setAdresse(requestMap.get("adresse"));


      medecin.setNationnalite(requestMap.get("nationnalite"));
      medecin.setPrenom(requestMap.get("prenom"));
      medecin.setNom(requestMap.get("nom"));
      medecin.setGenre(requestMap.get("genre"));
      medecin.setFax(requestMap.get("fax"));
      medecin.setEmail(requestMap.get("email"));
      medecin.setCode(requestMap.get("code"));
      medecin.setTel(requestMap.get("tel"));
      medecin.setImage(requestMap.get("image"));
      medecin.setCin(requestMap.get("cin"));
  medecin.setVille(requestMap.get("ville"));
        medecin.setDiplome(requestMap.get("diplome"));
        medecin.setDateNaissance(Date.valueOf(requestMap.get("dateNaissance")));
        List<Patient> patients = new ArrayList<>();
        /*String[] patientIds = requestMap.get("patients").split(",");
        for (String patientId : patientIds) {
            Patient patient = new Patient();
            patient.setId(Long.valueOf(patientId));
            patients.add(patient);
        }
        medecin.setPatients(patients);*/

        // Add Clinique
        if(requestMap.containsKey("cliniqueId")) {
            Long cliniqueId = Long.valueOf(requestMap.get("cliniqueId"));
            Clinique clinique = new Clinique();
            clinique.setId(cliniqueId);
            medecin.setClinique(clinique);
        }

        /*
        List<Specialite> specialites = new ArrayList<>();
        String[] specialiteValues = requestMap.get("specialites").split(",");
        for (String specialiteValue : specialiteValues) {
            Specialite specialite = Specialite.valueOf(specialiteValue);
            specialites.add(specialite);
        }
        medecin.setSpecialites(specialites);
*/

        return  medecin;
    }

    @Override
    public ResponseEntity<List<Medecin>> getAllMedecin(String filterValue) {
     try {
         if(!Strings.isNullOrEmpty(filterValue)&&filterValue.equalsIgnoreCase("true")){
             return new ResponseEntity<List<Medecin>>(medecinDao.getAllMedecin(),HttpStatus.OK);
         }
       return  new ResponseEntity<>(medecinDao.findAll(),HttpStatus.OK);
     }catch (Exception ex){
         ex.printStackTrace();
     }
     return  new ResponseEntity<List<Medecin>>(new ArrayList<>(),HttpStatus.INTERNAL_SERVER_ERROR);
    }



    @Override
    public Medecin getMedecinById(Long id)  {
        return medecinDao.findMedecinById(id)
                .orElseThrow(()->new MedecinNotFoundException("Medecin avec id"+id+"was not found"));

    }


    @Override
    public Medecin updateMedecin(Medecin medecin) {
        return medecinDao.save(medecin);
    }

    @Override
    public void deleteMedecin(Long id) {
         medecinDao.deleteById(id);
    }
}
