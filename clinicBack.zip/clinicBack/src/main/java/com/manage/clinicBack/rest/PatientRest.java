package com.manage.clinicBack.rest;

import com.manage.clinicBack.module.Medecin;
import com.manage.clinicBack.module.Patient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/patients")
public interface PatientRest {
    @GetMapping(path = "/all")
    public List<Patient> findAll() ;

    @GetMapping("/{id}")
    public Patient findById(@PathVariable Long id);

    @PostMapping(path = "/add")
    public Patient save(@RequestBody Patient patient) ;

    @PutMapping (path = "/update/{id}")
    public Patient update(@PathVariable Long id,@RequestBody Patient patient);
    @DeleteMapping("delete/{id}")
    public void deleteById(@PathVariable Long id) ;
}

