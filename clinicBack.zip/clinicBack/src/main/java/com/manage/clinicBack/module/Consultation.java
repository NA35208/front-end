package com.manage.clinicBack.module;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name="consultation")
public class Consultation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Medecin medecin;

    @ManyToOne
    private Patient patient;
    @ManyToOne
    private Clinique hospital;

}