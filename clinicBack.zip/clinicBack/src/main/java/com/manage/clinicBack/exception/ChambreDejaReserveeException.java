package com.manage.clinicBack.exception;

public class ChambreDejaReserveeException extends  RuntimeException{
    public ChambreDejaReserveeException(String message){  super(message);}
}
