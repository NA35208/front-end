package com.manage.clinicBack.service;

import com.manage.clinicBack.module.Clinique;
import com.manage.clinicBack.module.Medecin;
import com.manage.clinicBack.module.Patient;

import java.util.List;

public interface CliniqueService {
    List<Clinique> getAllCliniques();
    Clinique getCliniqueById(Long id);
    Clinique addClinique(Clinique clinique);
    Clinique updateClinique(Long id, Clinique clinique);
    void deleteClinique(Long id);
    public List<Medecin> getAllMedecins(Long cliniqueId);

    public Medecin getMedecinById(Long cliniqueId, Long medecinId);
    public Medecin addMedecin(Long cliniqueId, Medecin medecin);
    public Medecin updateMedecin(Long cliniqueId, Long medecinId, Medecin medecin);
    public void deleteMedecin(Long cliniqueId, Long medecinId);
    List<Patient> getAllPatientsByCliniqueId(Long cliniqueId);
    Patient getPatientById(Long cliniqueId, Long patientId);
    Patient addPatient(Long cliniqueId, Patient patient);
    Patient updatePatient(Long cliniqueId, Long patientId, Patient patient);
    void deletePatient(Long cliniqueId, Long patientId);

}
