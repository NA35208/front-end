package com.manage.clinicBack.restImpl;

import com.manage.clinicBack.module.DossierMedical;
import com.manage.clinicBack.rest.DossierMedicalRest;
import com.manage.clinicBack.service.DossierMedicalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DossierMedicalRestImpl implements DossierMedicalRest {
    @Autowired
    private DossierMedicalService dossierMedicalService;

    @Override

    public ResponseEntity<DossierMedical> createDossierMedical(@PathVariable Long patientId, @PathVariable Long medecinId, @RequestBody DossierMedical dossierMedical) {
        DossierMedical createdDossierMedical = dossierMedicalService.createDossierMedical(patientId, medecinId, dossierMedical);
        return new ResponseEntity<>(createdDossierMedical, HttpStatus.CREATED);
    }

    @Override

    public ResponseEntity<DossierMedical> updateDossierMedical(@PathVariable Long dossierMedicalId, @RequestBody DossierMedical dossierMedical) {
        DossierMedical updatedDossierMedical = dossierMedicalService.updateDossierMedical(dossierMedicalId, dossierMedical);
        return new ResponseEntity<>(updatedDossierMedical, HttpStatus.OK);
    }

    @Override

    public ResponseEntity<?> deleteDossierMedical(@PathVariable Long dossierMedicalId) {
        dossierMedicalService.deleteDossierMedical(dossierMedicalId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override

    public ResponseEntity<DossierMedical> getDossierMedicalById(@PathVariable Long dossierMedicalId) {
        DossierMedical dossierMedical = dossierMedicalService.getDossierMedicalById(dossierMedicalId);
        return new ResponseEntity<>(dossierMedical, HttpStatus.OK);
    }

}