package com.manage.clinicBack.restImpl;

import com.manage.clinicBack.constents.cliniqueConstants;
import com.manage.clinicBack.module.Medecin;
import com.manage.clinicBack.rest.MedecinRest;
import com.manage.clinicBack.service.MedecinService;
import com.manage.clinicBack.utils.ClinicUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class MedecinRestImpl implements MedecinRest {
   @Autowired
    MedecinService medecinService;

    @Override
    public ResponseEntity<String> addNewMedecin(Map<String, String> requestMap) {
      try {
        return medecinService.addNewMedecin(requestMap);
      }catch (Exception ex){
          ex.printStackTrace();
      }
      return ClinicUtils.getResponseEntity(cliniqueConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Override
    public ResponseEntity<List<Medecin>> getAllMedecin(String filterValue) {
      try {
          return medecinService.getAllMedecin(filterValue);

    }catch (Exception ex){
        ex.printStackTrace();
    }
        return new ResponseEntity<>(new ArrayList<>(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Override
    public ResponseEntity <Medecin> updateMedecin(Medecin medecin) {
        Medecin updateMedecin = medecinService.updateMedecin(medecin);
        return new ResponseEntity<>(updateMedecin, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> deleteMedecin(Long id) {

        medecinService.deleteMedecin(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @Override
    public ResponseEntity<Medecin> getMedecinById(Long id) {
        Medecin doctor = medecinService.getMedecinById(id);
        return ResponseEntity.ok().body(doctor);
    }


}

