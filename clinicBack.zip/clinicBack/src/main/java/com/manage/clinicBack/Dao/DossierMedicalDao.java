package com.manage.clinicBack.Dao;

import com.manage.clinicBack.module.DossierMedical;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DossierMedicalDao extends JpaRepository<DossierMedical,Long> {
}
