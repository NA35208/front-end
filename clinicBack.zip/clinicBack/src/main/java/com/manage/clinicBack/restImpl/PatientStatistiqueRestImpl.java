package com.manage.clinicBack.restImpl;
/*
import com.manage.clinicBack.module.Clinique;
import com.manage.clinicBack.rest.CliniqueStatistiqueRest;
import com.manage.clinicBack.service.PatientStatistiqueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class PatientStatistiqueRestImpl implements CliniqueStatistiqueRest {

    @Autowired
    private PatientStatistiqueService patientStatisticsService;

    @Override
    public ResponseEntity<Integer> countPatientsByAge(@PathVariable int age) {
        int count = patientStatisticsService.countPatientsByAge(age);
        return ResponseEntity.ok(count);
    }

    @Override
    public ResponseEntity<Integer> countPatientsByDisease(@PathVariable String disease) {
        int count = patientStatisticsService.countPatientsByDisease(disease);
        return ResponseEntity.ok(count);
    }

    @Override
    public ResponseEntity<Integer> countPatientsByGender(@PathVariable String gender) {
        int count = patientStatisticsService.countPatientsByGender(gender);
        return ResponseEntity.ok(count);
    }

    @Override
    public ResponseEntity<Integer> countPatientsByMonth(@PathVariable int month) {
        int count = patientStatisticsService.countPatientsByMonth(month);
        return ResponseEntity.ok(count);
    }

    @Override
    public ResponseEntity<Integer> countPatientsByYear(@PathVariable int year) {
        int count = patientStatisticsService.countPatientsByYear(year);
        return ResponseEntity.ok(count);
    }

    @Override
    public ResponseEntity<Integer> countPatientsByDay(@PathVariable int day) {
        int count = patientStatisticsService.countPatientsByDay(day);
        return ResponseEntity.ok(count);
    }
    @Override
    public ResponseEntity<Map<String, Integer>> countPatientsByClinique(@RequestParam("cliniqueId") Long cliniqueId) {
        Clinique clinique = new Clinique();
        clinique.setId(cliniqueId);
        int count = patientStatisticsService.countPatientsByClinique(clinique);
        Map<String, Integer> result = new HashMap<>();
        result.put("count", count);
        return ResponseEntity.ok(result);
    }
}
*/