package com.manage.clinicBack.module;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
@Table(name = "clinique")
public class Clinique {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nom")
    private String nomClinique;

    @Column(name = "prix_consultation")
    private double prixConsultation;
    private String image;
    @OneToMany
    private List<Medecin> medecins;

    @OneToMany
    private List<Patient> patients;

    @OneToMany
    private List<Chambre> chambres;
}




