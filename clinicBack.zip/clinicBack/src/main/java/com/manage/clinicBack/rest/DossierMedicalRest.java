package com.manage.clinicBack.rest;

import com.manage.clinicBack.module.DossierMedical;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

public interface DossierMedicalRest {
    @PostMapping("/patients/{patientId}/medecins/{medecinId}/dossiers-medicaux")
    ResponseEntity<DossierMedical> createDossierMedical(@PathVariable Long patientId, @PathVariable Long medecinId, @RequestBody DossierMedical dossierMedical);

    @PutMapping("/dossiers-medicaux/{dossierMedicalId}")
    ResponseEntity<DossierMedical> updateDossierMedical(@PathVariable Long dossierMedicalId, @RequestBody DossierMedical dossierMedical);

    @DeleteMapping("/dossiers-medicaux/{dossierMedicalId}")
    ResponseEntity<?> deleteDossierMedical(@PathVariable Long dossierMedicalId);

    @GetMapping("/dossiers-medicaux/{dossierMedicalId}")
    ResponseEntity<DossierMedical> getDossierMedicalById(@PathVariable Long dossierMedicalId);
}
