package com.manage.clinicBack.rest;

import com.manage.clinicBack.module.ReservationChambreDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/reservation")
public interface ReservationRest {
    @PostMapping
    public ResponseEntity<?> reserverChambre(@RequestBody ReservationChambreDTO reservationChambreDTO);

}
