package com.manage.clinicBack.rest;

import com.manage.clinicBack.Dao.MedecinDao;
import com.manage.clinicBack.module.Medecin;
import com.manage.clinicBack.wrapper.UserWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RequestMapping(path="/medecin")

public interface MedecinRest {

    @PostMapping(path ="/add")
   ResponseEntity<String> addNewMedecin(@RequestBody(required = true) Map<String,String> requestMap );
   @GetMapping(path = "/all")
    ResponseEntity<List<Medecin>>getAllMedecin(@RequestParam(required = false) String filterValue);

   

   @PutMapping (path = "/update")
    ResponseEntity<Medecin>updateMedecin(@RequestBody Medecin medecin);
   @DeleteMapping(path = "/delete/{id}")
    ResponseEntity<?>deleteMedecin(@PathVariable("id") Long id);
   @GetMapping(path = "/getbyId/{id}")
    ResponseEntity<Medecin> getMedecinById(@PathVariable Long id) ;

}
