package com.manage.clinicBack.rest;

import com.manage.clinicBack.module.Clinique;
import com.manage.clinicBack.module.Medecin;
import com.manage.clinicBack.module.Patient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RequestMapping("/clinique")
public interface CliniqueRest {
    @GetMapping("/all")
    List<Clinique> getAllCliniques();

    @GetMapping("/{id}")
    Clinique getCliniqueById(@PathVariable Long id);

    @PostMapping("/add")
    Clinique addClinique(@RequestBody Clinique clinique);

    @PutMapping("/update/{id}")
    Clinique updateClinique(@PathVariable Long id, @RequestBody Clinique clinique);

    @DeleteMapping("/delete/{id}")
    void deleteClinique(@PathVariable Long id);
    @GetMapping("{cliniqueId}/medecins/all")
    public List<Medecin> getAllMedecins(@PathVariable Long cliniqueId);
    @GetMapping("{cliniqueId}/medecins/{medecinId}")
    public Medecin getMedecinById(@PathVariable Long cliniqueId, @PathVariable Long medecinId);

    @PostMapping("{cliniqueId}/medecins")
    public Medecin addMedecin(@PathVariable Long cliniqueId, @RequestBody Medecin medecin);
    @PutMapping("{cliniqueId}/medecins/{medecinId}")
    public Medecin updateMedecin(@PathVariable Long cliniqueId, @PathVariable Long medecinId, @RequestBody Medecin medecin);
    @DeleteMapping("{cliniqueId}/medecins/{medecinId}")
    public void deleteMedecin(@PathVariable Long cliniqueId, @PathVariable Long medecinId);
    @GetMapping("{cliniqueId}/patients")
    public List<Patient> getAllPatientsByCliniqueId(@PathVariable Long cliniqueId);
    @GetMapping("/patients/{patientId}")
    public Patient getPatientById(@PathVariable Long cliniqueId, @PathVariable Long patientId);
    @PostMapping("/patients")
    public Patient addPatient(@PathVariable Long cliniqueId, @RequestBody Patient patient);
    @PutMapping("/patients/{patientId}")
    public Patient updatePatient(@PathVariable Long cliniqueId, @PathVariable Long patientId, @RequestBody Patient patient);
    @DeleteMapping("/patients/{patientId}")
    public void deletePatient(@PathVariable Long cliniqueId, @PathVariable Long patientId);


}

