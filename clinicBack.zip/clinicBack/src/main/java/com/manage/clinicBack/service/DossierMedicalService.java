package com.manage.clinicBack.service;

import com.manage.clinicBack.module.DossierMedical;

public interface DossierMedicalService {
    DossierMedical createDossierMedical(Long patientId, Long medecinId, DossierMedical dossierMedical);
    DossierMedical updateDossierMedical(Long dossierMedicalId, DossierMedical dossierMedical);
    void deleteDossierMedical(Long dossierMedicalId);
    DossierMedical getDossierMedicalById(Long dossierMedicalId);
}

