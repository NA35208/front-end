package com.manage.clinicBack.seviceImpl;
/*
import com.manage.clinicBack.Dao.PatientDao;
import com.manage.clinicBack.module.Clinique;
import com.manage.clinicBack.service.PatientStatistiqueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;

@Service
public class PatientStatisticsServiceImpl implements PatientStatistiqueService {

    @Autowired
    private PatientDao patientRepository;

    @Override
    public int countPatientsByAge(int age) {
        return patientRepository.countByAge(age);
    }

    @Override
    public int countPatientsByDisease(String disease) {
        return patientRepository.countByDisease(disease);
    }

    @Override
    public int countPatientsByGender(String gender) {
        return patientRepository.countByGender(gender);
    }

    @Override
    public int countPatientsByMonth(int month) {
        return patientRepository.countByMonth(month);
    }

    @Override
    public int countPatientsByYear(int year) {
        return patientRepository.countByYear(year);
    }

    @Override
    public int countPatientsByDay(int day) {
        return patientRepository.countByDay(day);
    }

    @Override
    public int countPatientsByClinique(Clinique clinique) {
        return patientRepository.countByClinique(clinique);
    }


}*/
