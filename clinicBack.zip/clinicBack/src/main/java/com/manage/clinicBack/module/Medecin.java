package com.manage.clinicBack.module;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
//@NamedQuery(name = "Medecin.getAllMedecin()",query = "select c from medecins c  ")
@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@DynamicInsert

@Table(name="medecins")
public class Medecin implements Serializable {
    private static  final  long serialVersionUID=1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private     Long id;
    private String code;
    private String cin;
    private String nom;
    private  String prenom;
    @JsonFormat(shape=JsonFormat.Shape.STRING,pattern ="yyyy-MM-dd",timezone = "GMT")
    private Date dateNaissance;
    private  String genre;
    private String adresse;
    private String ville;
    private  String tel;

    private String email;
    private String fax;
    private String nationnalite;

   private String image;

    @ManyToOne
    @JoinColumn(name = "clinique_id")
    private Clinique clinique;

    private  String diplome;
    @ManyToMany
    @JoinTable(name = "medecin_patient",
            joinColumns = @JoinColumn(name = "medecin_id"),
            inverseJoinColumns = @JoinColumn(name = "patient_id"))
    private List<Patient> patients;

    private List<Specialite> specialites;
    public void setClinique(Clinique clinique) {
        this.clinique = clinique;
    }
}
