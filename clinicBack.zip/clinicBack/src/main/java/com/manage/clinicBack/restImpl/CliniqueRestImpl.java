package com.manage.clinicBack.restImpl;

import com.manage.clinicBack.module.Clinique;
import com.manage.clinicBack.module.Medecin;
import com.manage.clinicBack.module.Patient;
import com.manage.clinicBack.rest.CliniqueRest;
import com.manage.clinicBack.service.CliniqueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CliniqueRestImpl implements CliniqueRest {

    @Autowired
    private CliniqueService cliniqueService;

    @Override
    public List<Clinique> getAllCliniques() {
        return cliniqueService.getAllCliniques();
    }

    @Override
    public Clinique getCliniqueById(Long id) {
        return cliniqueService.getCliniqueById(id);
    }

    @Override
    public Clinique addClinique(Clinique clinique) {
        return cliniqueService.addClinique(clinique);
    }

    @Override
    public Clinique updateClinique(Long id, Clinique clinique) {
        return cliniqueService.updateClinique(id, clinique);
    }

    @Override
    public void deleteClinique(Long id) {
        cliniqueService.deleteClinique(id);
    }
    public CliniqueRestImpl(CliniqueService cliniqueService) {
        this.cliniqueService = cliniqueService;
    }

    @Override

    public List<Medecin> getAllMedecins(@PathVariable Long cliniqueId) {
        return cliniqueService.getAllMedecins(cliniqueId);
    }

    @Override

    public Medecin getMedecinById(@PathVariable Long cliniqueId, @PathVariable Long medecinId) {
        return cliniqueService.getMedecinById(cliniqueId, medecinId);
    }

    @Override

    public Medecin addMedecin(@PathVariable Long cliniqueId, @RequestBody Medecin medecin) {
        return cliniqueService.addMedecin(cliniqueId, medecin);
    }

    @Override

    public Medecin updateMedecin(@PathVariable Long cliniqueId, @PathVariable Long medecinId, @RequestBody Medecin medecin) {
        return cliniqueService.updateMedecin(cliniqueId, medecinId, medecin);
    }

    @Override

    public void deleteMedecin(@PathVariable Long cliniqueId, @PathVariable Long medecinId) {
        cliniqueService.deleteMedecin(cliniqueId, medecinId);
    }

    @Override

    public List<Patient> getAllPatientsByCliniqueId(@PathVariable Long cliniqueId) {
        return cliniqueService.getAllPatientsByCliniqueId(cliniqueId);
    }

    @Override

    public Patient getPatientById(@PathVariable Long cliniqueId, @PathVariable Long patientId) {
        return cliniqueService.getPatientById(cliniqueId, patientId);
    }

    @Override

    public Patient addPatient(@PathVariable Long cliniqueId, @RequestBody Patient patient) {
        return cliniqueService.addPatient(cliniqueId, patient);
    }

    @Override

    public Patient updatePatient(@PathVariable Long cliniqueId, @PathVariable Long patientId, @RequestBody Patient patient) {
        return cliniqueService.updatePatient(cliniqueId, patientId, patient);
    }

    @Override

    public void deletePatient(@PathVariable Long cliniqueId, @PathVariable Long patientId) {
        cliniqueService.deletePatient(cliniqueId, patientId);
    }
}

