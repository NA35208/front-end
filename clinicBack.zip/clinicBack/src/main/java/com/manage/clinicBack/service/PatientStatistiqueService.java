package com.manage.clinicBack.service;

import com.manage.clinicBack.module.Clinique;
/*
public interface PatientStatistiqueService {
    public int countPatientsByAge(int age);

    public int countPatientsByDisease(String disease);

    public int countPatientsByGender(String gender);

    public int countPatientsByMonth(int month);
    public int countPatientsByYear(int year);
    public int countPatientsByDay(int day);
    public int countPatientsByClinique(Clinique clinique);
}
*/