package com.manage.clinicBack.exception;

public class ChambreNotFoundException extends  RuntimeException{
    public ChambreNotFoundException(String message){  super(message);}
}
