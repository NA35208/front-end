package com.manage.clinicBack.seviceImpl;

import com.manage.clinicBack.Dao.DossierMedicalDao;
import com.manage.clinicBack.Dao.MedecinDao;
import com.manage.clinicBack.Dao.PatientDao;
import com.manage.clinicBack.exception.UserNotFoundException;
import com.manage.clinicBack.module.DossierMedical;
import com.manage.clinicBack.module.Medecin;
import com.manage.clinicBack.module.Patient;
import com.manage.clinicBack.service.DossierMedicalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class DossierMedicalServiceImpl implements DossierMedicalService {

    @Autowired
    private DossierMedicalDao dossierMedicalRepository;

    @Autowired
    private PatientDao patientRepository;

    @Autowired
    private MedecinDao medecinRepository;

    @Override
    public DossierMedical createDossierMedical(Long patientId, Long medecinId, DossierMedical dossierMedical) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new UserNotFoundException("Patient id"+patientId));

        Medecin medecin = medecinRepository.findById(medecinId)
                .orElseThrow(() -> new UserNotFoundException("Medecin id"+medecinId));

        dossierMedical.setPatient(patient);
        dossierMedical.setMedecin(medecin);

        return dossierMedicalRepository.save(dossierMedical);
    }

    @Override
    public DossierMedical updateDossierMedical(Long dossierMedicalId, DossierMedical dossierMedical) {
        DossierMedical existingDossierMedical = dossierMedicalRepository.findById(dossierMedicalId)
                .orElseThrow(() -> new UserNotFoundException("DossierMedical id"+dossierMedicalId));

        existingDossierMedical.setAllergies(dossierMedical.getAllergies());
        existingDossierMedical.setAntecedents(dossierMedical.getAntecedents());
        existingDossierMedical.setObservations(dossierMedical.getObservations());
   existingDossierMedical.setMaladie(dossierMedical.getMaladie());
        return dossierMedicalRepository.save(existingDossierMedical);
    }

    @Override
    public void deleteDossierMedical(Long dossierMedicalId) {
        DossierMedical dossierMedical = dossierMedicalRepository.findById(dossierMedicalId)
                .orElseThrow(() ->  new UserNotFoundException("DossierMedical id"+dossierMedicalId));

        dossierMedicalRepository.delete(dossierMedical);
    }

    @Override
    public DossierMedical getDossierMedicalById(Long dossierMedicalId) {
        return dossierMedicalRepository.findById(dossierMedicalId)
                .orElseThrow(() -> new UserNotFoundException("DossierMedical id"+dossierMedicalId));
    }
}
