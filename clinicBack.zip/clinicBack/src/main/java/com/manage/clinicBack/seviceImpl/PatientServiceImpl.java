package com.manage.clinicBack.seviceImpl;

import com.manage.clinicBack.Dao.PatientDao;
import com.manage.clinicBack.module.Patient;
import com.manage.clinicBack.service.PatientService;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Transactional
@Slf4j
@Service
public class PatientServiceImpl implements PatientService {
    @Autowired
    private PatientDao patientRepository;

    @Override
    public List<Patient> findAll() {
        return patientRepository.findAll();
    }

    @Override
    public Patient findById(Long id) {
        return patientRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("Patient not found with id: " + id));
    }

    @Override
    public Patient save(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    public void deleteById(Long id) {
        patientRepository.deleteById(id);
    }
}

