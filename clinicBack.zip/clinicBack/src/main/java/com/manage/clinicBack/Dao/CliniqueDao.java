package com.manage.clinicBack.Dao;

import com.manage.clinicBack.module.Clinique;
import com.manage.clinicBack.module.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface CliniqueDao extends JpaRepository<Clinique,Long>{

}
