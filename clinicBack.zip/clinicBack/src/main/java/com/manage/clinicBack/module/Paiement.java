package com.manage.clinicBack.module;

public class Paiement {
}
