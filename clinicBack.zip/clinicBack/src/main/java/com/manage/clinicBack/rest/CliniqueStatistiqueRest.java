package com.manage.clinicBack.rest;
/*
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@RequestMapping("/cliniques")
public interface CliniqueStatistiqueRest {
    @GetMapping("/patients/count-by-age/{age}")
    public ResponseEntity<Integer> countPatientsByAge(@PathVariable int age);
    @GetMapping("/patients/count-by-disease/{disease}")
    public ResponseEntity<Integer> countPatientsByDisease(@PathVariable String disease);

    @GetMapping("/patients/count-by-gender/{gender}")
    public ResponseEntity<Integer> countPatientsByGender(@PathVariable String gender);
    @GetMapping("/patients/count-by-month/{month}")
    public ResponseEntity<Integer> countPatientsByMonth(@PathVariable int month);
    @GetMapping("/patients/count-by-year/{year}")
    public ResponseEntity<Integer> countPatientsByYear(@PathVariable int year);
    @GetMapping("/patients/count-by-day/{day}")
    public ResponseEntity<Integer> countPatientsByDay(@PathVariable int day);
    @GetMapping("/count-by-clinique")
    public ResponseEntity<Map<String, Integer>> countPatientsByClinique(@RequestParam("cliniqueId") Long cliniqueId);

}
*/