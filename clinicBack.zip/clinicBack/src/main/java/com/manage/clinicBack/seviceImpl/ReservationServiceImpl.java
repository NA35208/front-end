package com.manage.clinicBack.seviceImpl;

import com.manage.clinicBack.Dao.ChambreDao;
import com.manage.clinicBack.exception.ChambreDejaReserveeException;
import com.manage.clinicBack.exception.ChambreNotFoundException;
import com.manage.clinicBack.module.Chambre;
import com.manage.clinicBack.module.ReservationChambreDTO;
import com.manage.clinicBack.service.ReservationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
@Transactional
@Service
public class ReservationServiceImpl implements ReservationService {

    private final ChambreDao chambreRepository;

    public ReservationServiceImpl(ChambreDao chambreRepository) {
        this.chambreRepository = chambreRepository;
    }

    @Override
    public void reserverChambre(ReservationChambreDTO reservationChambreDTO) {
        Optional<Chambre> chambreOptional = chambreRepository.findByNumeroAndHopitalId(reservationChambreDTO.getNumeroChambre(), reservationChambreDTO.getIdHopital());

        if (chambreOptional.isPresent()) {
            Chambre chambre = chambreOptional.get();
            if (!chambre.isReservee()) {
                chambre.setReservee(true);
                chambreRepository.save(chambre);
            } else {
                throw new ChambreDejaReserveeException("La chambre " + chambre.getNumero() + " est déjà réservée");
            }
        } else {
            throw new ChambreNotFoundException("La chambre " + reservationChambreDTO.getNumeroChambre() + " n'existe pas dans l'hôpital " + reservationChambreDTO.getIdHopital());
        }
    }
}