package com.manage.clinicBack.restImpl;

import com.manage.clinicBack.exception.ChambreDejaReserveeException;
import com.manage.clinicBack.exception.ChambreNotFoundException;
import com.manage.clinicBack.module.ReservationChambreDTO;
import com.manage.clinicBack.rest.ReservationRest;
import com.manage.clinicBack.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ReservationRestImpl implements ReservationRest {
    @Autowired
    ReservationService reservationService;
    public  ReservationRestImpl(ReservationService reservationService){
        this.reservationService=reservationService;
    }

    @Override
    public ResponseEntity<?> reserverChambre(ReservationChambreDTO reservationChambreDTO) {
        try {
            reservationService.reserverChambre(reservationChambreDTO);
            return ResponseEntity.ok().build();
        } catch (ChambreNotFoundException | ChambreDejaReserveeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
