package com.manage.clinicBack.Dao;

//import com.manage.clinicBack.module.Clinique;
import com.manage.clinicBack.module.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface PatientDao extends JpaRepository<Patient,Long> {
    /*
    int countByAge(int age);

    int countByDisease(String disease);

    int countByGender(String gender);

    int countByMonth(int month);

    int countByYear(int year);

    int countByDay(int day);

    int countByClinique(Clinique clinique);

     */
}
